# Power BI Dashboard Guide — Cyber Security Analytics

This guide walks through building the Power BI dashboard from `network_security_logs_powerbi.csv`.

## 1. Load the Data
1. Open Power BI Desktop → **Get Data** → **Text/CSV**
2. Select `network_security_logs_powerbi.csv`
3. In Power Query Editor, set data types:
   - `timestamp` → Date/Time
   - `is_attack`, `blocked`, `failed_logins`, `dest_port` → Whole Number
   - `bytes_transferred`, `session_duration_sec` → Decimal Number
4. Click **Close & Apply**

## 2. Create Key Measures (DAX)
```DAX
Total Events = COUNTROWS(logs)

Total Attacks = SUM(logs[is_attack])

Attack Rate % = DIVIDE([Total Attacks], [Total Events], 0) * 100

Block Rate % =
DIVIDE(
    CALCULATE(SUM(logs[blocked]), logs[is_attack] = 1),
    CALCULATE(COUNTROWS(logs), logs[is_attack] = 1),
    0
) * 100

Critical Events = CALCULATE(COUNTROWS(logs), logs[severity] = "Critical")
```

## 3. Build the Dashboard Pages

### Page 1 — Executive Overview
- **KPI Cards**: Total Events, Total Attacks, Attack Rate %, Block Rate %, Critical Events
- **Donut Chart**: Severity distribution (`severity` field)
- **Bar Chart**: Events by Attack Type (`attack_type`, count)
- **Line Chart**: Daily attack trend (`date` on X-axis, `Total Attacks` measure on Y-axis)

### Page 2 — Threat Intelligence
- **Map Visual**: Attacks by `source_country` (use a Filled Map or Bar Chart if geo data is limited)
- **Bar Chart**: Top 10 source countries by attack count
- **Matrix Table**: Attack Type × Severity × Block Rate %
- **Stacked Column**: Protocol usage split by `is_attack`

### Page 3 — Operational Detail
- **Table**: Critical, unblocked events (filter `severity = Critical` AND `blocked = 0`)
- **Heatmap-style Matrix**: Hour of day (X) vs Attack Type (Y), count as values
- **Slicers**: Date range, Attack Type, Severity, Source Country

## 4. Formatting Tips
- Use a dark theme (View → Themes → "Executive" or custom dark navy) — fits a SOC/security dashboard aesthetic
- Color code severity consistently: Low = green, Medium = amber, High = orange, Critical = red
- Add a title text box: "Network Security Analytics Dashboard"
- Pin the Executive Overview page as the dashboard cover when sharing

## 5. Publish & Share
1. **File → Publish → Publish to Power BI** (requires a Power BI account)
2. Or export as PDF: **File → Export → Export to PDF** for resume/portfolio use
3. Take a screenshot of each page and add to your GitHub repo's `visuals/` folder as `powerbi_dashboard_pageX.png`

---
**Why this matters for the data analyst role**: this dashboard demonstrates KPI design, DAX measures, multi-page storytelling, and an ability to translate raw security logs into decision-ready visuals — directly relevant to BI/analyst roles.
