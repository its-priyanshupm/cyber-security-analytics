"""
Loads network_security_logs.csv into a SQLite database (logs.db)
so the SQL queries in analysis_queries.sql can be run directly.
"""
import sqlite3
import pandas as pd

df = pd.read_csv("/home/claude/cyber-security-analytics/data/network_security_logs.csv")
conn = sqlite3.connect("/home/claude/cyber-security-analytics/sql/logs.db")
df.to_sql("logs", conn, if_exists="replace", index=False)

# Quick sanity check: run query #2 from the file
cur = conn.cursor()
cur.execute("""
    SELECT attack_type, COUNT(*) as cnt
    FROM logs GROUP BY attack_type ORDER BY cnt DESC
""")
print("Sample query result (attack type counts):")
for row in cur.fetchall():
    print(row)

conn.close()
print("\nlogs.db created successfully.")
